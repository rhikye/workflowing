def hello_world():
    print("Hello World")

def add(a: int, b: int):
    return a + b
